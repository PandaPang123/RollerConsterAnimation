//
//  main.m
//  RollerCoasterAnimation
//
//  Created by Pandapan on 2018/3/23.
//  Copyright © 2018年 Pandapan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
