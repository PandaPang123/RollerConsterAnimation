//
//  ViewController.m
//  RollerCoasterAnimation
//
//  Created by Pandapan on 2018/3/23.
//  Copyright © 2018年 Pandapan. All rights reserved.
//

#import "ViewController.h"

#define k_SCREEN_HEIGHT [UIScreen mainScreen].bounds.size.height
#define k_LAND_BEGIN_HEIGHT k_SCREEN_HEIGHT - 20
#define SCREENSIZE self.view.frame.size
@interface ViewController ()

@property(strong,nonatomic)CALayer *landLayer;
@property(strong,nonatomic)CAShapeLayer *greenTrack;
@property(strong,nonatomic)CAShapeLayer *yellowTrack;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor lightGrayColor];
    [self initBackgroundSky];
    [self initSnowMountain];
    [self initCloudAnimation];
    [self initLand];
    [self initLawn];
    [self initYellowTrack];
    [self carAnimationWith:@"car" TrackLayer:_yellowTrack AnimationDuration:8.0 BeginTime:CACurrentMediaTime()+1];
    [self initGreenTrack];
    [self carAnimationWith:@"car1" TrackLayer:_greenTrack AnimationDuration:6.0 BeginTime:CACurrentMediaTime()];
    [self initTree];
}
//渐变的天空
-(void)initBackgroundSky{
    CAGradientLayer *layer = [[CAGradientLayer alloc] init];
    layer.frame = CGRectMake(0, 0, SCREENSIZE.width, SCREENSIZE.height);
    UIColor *lightColor = [UIColor colorWithRed:40.0f/255.0f green:150.0f/255.0f blue:200.0f/255.0f alpha:1.0];
    UIColor *darkColor = [UIColor colorWithRed:255.0f/255.0f green:250.0f/255.0f blue:250.0f/255.0f alpha:1.0];
    layer.colors = @[(__bridge id)lightColor.CGColor,(__bridge id)darkColor.CGColor];
    
    //    让变色层成45度角变色
    layer.startPoint = CGPointMake(0, 0);
    layer.endPoint = CGPointMake(1, 1);
    
    [self.view.layer addSublayer:layer];
}
//初始化云朵
-(void)initCloudAnimation{
    CALayer *layer = [[CALayer alloc] init];
    layer.contents = (__bridge id _Nullable)([UIImage imageNamed:@"cloud"].CGImage);
    layer.frame = CGRectMake(0, 0, 63, 20);
    [self.view.layer addSublayer:layer];
    
    UIBezierPath *bezierPath = [[UIBezierPath alloc] init];
    [bezierPath moveToPoint:CGPointMake(SCREENSIZE.width+63, 50)];
    [bezierPath addLineToPoint:CGPointMake(-63, 50)];
    
    CAKeyframeAnimation *animation = [CAKeyframeAnimation animationWithKeyPath:@"position"];
    animation.path = bezierPath.CGPath;
    animation.duration = 30;
    animation.autoreverses = NO;
    animation.repeatCount = CGFLOAT_MAX;
    animation.calculationMode = kCAAnimationPaced;
    [layer addAnimation:animation forKey:@"position"];
    
}
//初始化土地
-(void)initLand{
    _landLayer = [[CALayer alloc] init];
    _landLayer.frame = CGRectMake(0, k_LAND_BEGIN_HEIGHT, SCREENSIZE.width, 20);
    _landLayer.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"ground"]].CGColor;
    [self.view.layer addSublayer:_landLayer];
}
//初始化草坪
-(void)initLawn{
    CAShapeLayer *leftLawn = [[CAShapeLayer alloc] init];
    UIBezierPath *leftPath = [[UIBezierPath alloc] init];
    CGPoint leftStartPoint = CGPointMake(0, k_LAND_BEGIN_HEIGHT);
    [leftPath moveToPoint:leftStartPoint];
    [leftPath addLineToPoint:CGPointMake(0, SCREENSIZE.height-100)];
//    二次贝塞尔曲线
    [leftPath addQuadCurveToPoint:CGPointMake(SCREENSIZE.width/3.0, k_LAND_BEGIN_HEIGHT) controlPoint:CGPointMake(SCREENSIZE.width/5.0, SCREENSIZE.height-100)];
    leftLawn.path = leftPath.CGPath;
    leftLawn.fillColor = [UIColor colorWithDisplayP3Red:82.0 / 255.0 green:177.0 / 255.0 blue:52.0 / 255.0 alpha:1.0].CGColor;
    [self.view.layer addSublayer:leftLawn];
    
//    右边草坪
    CAShapeLayer *rightLawn = [[CAShapeLayer alloc] init];
    UIBezierPath *rightPath = [[UIBezierPath alloc] init];
    [rightPath moveToPoint:leftStartPoint];
    //    二次贝塞尔曲线
    [rightPath addQuadCurveToPoint:CGPointMake(SCREENSIZE.width, SCREENSIZE.height-80) controlPoint:CGPointMake(SCREENSIZE.width/2.0, SCREENSIZE.height-100)];
    [rightPath addLineToPoint:CGPointMake(SCREENSIZE.width, k_LAND_BEGIN_HEIGHT)];
    rightLawn.path = rightPath.CGPath;
    rightLawn.fillColor = [UIColor colorWithDisplayP3Red:92.0 / 255.0 green:195.0 / 255.0 blue:52.0 / 255.0 alpha:1.0].CGColor;
    [self.view.layer insertSublayer:rightLawn above:leftLawn];
}
//树
-(void)initTree{
    
    [self addTreesWithNumber:7 treeFrame:CGRectMake(0, k_LAND_BEGIN_HEIGHT - 20, 13, 23)];
    [self addTreesWithNumber:7 treeFrame:CGRectMake(0, k_LAND_BEGIN_HEIGHT - 64, 18, 32)];
    [self addTreesWithNumber:2 treeFrame:CGRectMake(0, k_LAND_BEGIN_HEIGHT - 80, 13, 23)];
}
-(void)addTreesWithNumber:(NSInteger)treesNumber treeFrame:(CGRect)frame{
    UIImage *tree = [UIImage imageNamed:@"tree"];
    for (NSInteger i = 0; i < treesNumber + 1; i++) {
        CALayer *treeLayer = [[CALayer alloc] init];
        treeLayer.contents = (__bridge id _Nullable)(tree.CGImage);
        treeLayer.frame = CGRectMake(SCREENSIZE.width - 50 * i * (arc4random_uniform(4) + 1), frame.origin.y, frame.size.width, frame.size.height);
        [self.view.layer insertSublayer:treeLayer above:_greenTrack];
    }
}
//雪山
-(void)initSnowMountain{
    //    左边第一座山顶,其实就是一个白色的三角形
    CAShapeLayer *leftSnow = [[CAShapeLayer alloc] init];
    UIBezierPath *leftPath = [[UIBezierPath alloc] init];
    //    把bezierpath的起点移动到雪山左下角
    [leftPath moveToPoint:CGPointMake(0, SCREENSIZE.height-120)];
    //    画一条线到山顶
    [leftPath addLineToPoint:CGPointMake(100, 100)];
    //    画一条线到右下角->左下角->闭合
    [leftPath addLineToPoint:CGPointMake(SCREENSIZE.width / 2, k_LAND_BEGIN_HEIGHT)];
    [leftPath addLineToPoint:CGPointMake(0, k_LAND_BEGIN_HEIGHT)];
    [leftPath closePath];
    
    leftSnow.path = leftPath.CGPath;
    leftSnow.fillColor = [UIColor whiteColor].CGColor;
    [self.view.layer addSublayer:leftSnow];
    //    开始画山体没有被雪覆盖的部分
    CAShapeLayer *leftSnowbergBody = [[CAShapeLayer alloc] init];
    UIBezierPath *leftSnowbergBodyPath = [[UIBezierPath alloc] init];
    
    //    把bezierpath的起点移动到雪山左下角相同的位置
    CGPoint startPoint = CGPointMake(0, SCREENSIZE.height - 120);
    CGPoint endPoint = CGPointMake(100, 100);
    CGPoint firstPathPoint = [self calculateWithXValue:40 startPoint:startPoint endpoint:endPoint];
    [leftSnowbergBodyPath moveToPoint:startPoint];
    [leftSnowbergBodyPath addLineToPoint:firstPathPoint];
    [leftSnowbergBodyPath addLineToPoint:CGPointMake(60, firstPathPoint.y)];
    [leftSnowbergBodyPath addLineToPoint:CGPointMake(100, firstPathPoint.y + 30)];
    [leftSnowbergBodyPath addLineToPoint:CGPointMake(140, firstPathPoint.y)];
    [leftSnowbergBodyPath addLineToPoint:CGPointMake(155, firstPathPoint.y)];
    [leftSnowbergBodyPath addLineToPoint:CGPointMake(SCREENSIZE.width / 2, k_LAND_BEGIN_HEIGHT)];
    [leftSnowbergBodyPath addLineToPoint:CGPointMake(0, k_LAND_BEGIN_HEIGHT)];
    [leftSnowbergBodyPath closePath];
    leftSnowbergBody.path = leftSnowbergBodyPath.CGPath;
    UIColor *snowColor = [UIColor colorWithDisplayP3Red:139.0 /255.0 green:92.0 /255.0 blue:0.0 /255.0 alpha:1.0];
    leftSnowbergBody.fillColor = snowColor.CGColor;
    [self.view.layer addSublayer:leftSnowbergBody];
    
    CAShapeLayer *middleSnow = [[CAShapeLayer alloc] init];
    UIBezierPath *middlePath = [[UIBezierPath alloc] init];
    //    把bezierpath的起点移动到雪山左下角。然后画一条线到山顶，再画一条线到右下角，闭合。
    CGPoint middleStartPoint = CGPointMake(SCREENSIZE.width/3, k_LAND_BEGIN_HEIGHT);
    CGPoint middleTopPoint = CGPointMake(SCREENSIZE.width/2, 200);
    CGPoint middleEndPoint = CGPointMake(SCREENSIZE.width / 1.2, k_LAND_BEGIN_HEIGHT);
    
    [middlePath moveToPoint:middleStartPoint];
    [middlePath addLineToPoint:middleTopPoint];
    [middlePath addLineToPoint:middleEndPoint];
    
    [middlePath closePath];
    
    middleSnow.path = middlePath.CGPath;
    middleSnow.fillColor = [UIColor whiteColor].CGColor;
    [self.view.layer insertSublayer:middleSnow above:leftSnowbergBody];
    
    CAShapeLayer *middleSnowbergBody = [[CAShapeLayer alloc] init];
    UIBezierPath *middleSnowbergBodyPath = [[UIBezierPath alloc] init];
    [middleSnowbergBodyPath moveToPoint:middleStartPoint];
    CGPoint middleFirstPathPoint = [self calculateWithXValue:(middleStartPoint.x + 70) startPoint:middleStartPoint endpoint:middleTopPoint];
    NSLog(@"%lf,%lf",middleFirstPathPoint.x,middleFirstPathPoint.y);
    [middleSnowbergBodyPath addLineToPoint:middleFirstPathPoint];
    [middleSnowbergBodyPath addLineToPoint:middleEndPoint];

    [middleSnowbergBodyPath closePath];

    middleSnowbergBody.path = middleSnowbergBodyPath.CGPath;
    UIColor *middleSnowColor = [UIColor colorWithDisplayP3Red:125.0 /255.0 green:87.0 /255.0 blue:7.0 /255.0 alpha:1.0];
    middleSnowbergBody.fillColor = middleSnowColor.CGColor;
    [self.view.layer insertSublayer:middleSnowbergBody above:middleSnow];
    
    
}
//根据起始点，算出指定的x在这条线段上对应的y。返回这个point。知道两点，根据两点坐标，求出两点连线的斜率。y=kx+b求出点坐标。
- (CGPoint)calculateWithXValue:(CGFloat)xvalue startPoint:(CGPoint)startPoint endpoint:(CGPoint)endpoint{
    //    求出两点连线的斜率
    CGFloat k = (endpoint.y - startPoint.y) / (endpoint.x - startPoint.x);
    CGFloat b = startPoint.y - startPoint.x * k;
    CGFloat yvalue = k * xvalue + b;
    return CGPointMake(xvalue, yvalue);
}
-(void)initYellowTrack{
    _yellowTrack = [[CAShapeLayer alloc] init];
    _yellowTrack.lineWidth = 5;
    _yellowTrack.strokeColor = [UIColor colorWithDisplayP3Red:210.0 / 255.0 green:179.0 / 255.0 blue:54.0 / 255.0 alpha:1.0].CGColor;
    
    UIBezierPath *trackPath = [[UIBezierPath alloc] init];
    //    画一个三次贝塞尔曲线+一个二次贝塞尔曲线
    //    左侧两个拐弯的三次贝塞尔曲线
    [trackPath moveToPoint:CGPointMake(0, SCREENSIZE.height - 60)];
    [trackPath addCurveToPoint:CGPointMake(SCREENSIZE.width / 1.5, SCREENSIZE.height / 2.0 - 20) controlPoint1:CGPointMake(SCREENSIZE.width / 6.0, SCREENSIZE.height - 200) controlPoint2:CGPointMake(SCREENSIZE.width / 3.0, SCREENSIZE.height + 50)];
    //    右侧一个弯度的二次贝塞尔曲线
    [trackPath addQuadCurveToPoint:CGPointMake(SCREENSIZE.width + 50, SCREENSIZE.height / 3.0) controlPoint:CGPointMake(SCREENSIZE.width - 100, 50)];
    
    [trackPath addLineToPoint:CGPointMake(SCREENSIZE.width + 10, SCREENSIZE.height + 10)];
    [trackPath addLineToPoint:CGPointMake(0, SCREENSIZE.height + 10)];
    
    _yellowTrack.fillColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"yellow"]].CGColor;
    _yellowTrack.path = trackPath.CGPath;
    [self.view.layer insertSublayer:_yellowTrack below:_landLayer];
    
    //    为了能够让弧线更好看一点，需要加入镂空的虚线
    CAShapeLayer *trackLine = [[CAShapeLayer alloc] init];
    trackLine.lineCap = kCALineCapRound;
    trackLine.strokeColor = [UIColor whiteColor].CGColor;
    
    trackLine.lineDashPattern = @[@1.0,@6.0];
    trackLine.lineWidth = 2.5;
    trackLine.fillColor = [UIColor clearColor].CGColor;
    trackLine.path = trackPath.CGPath;
    [_yellowTrack addSublayer:trackLine];
    
}
- (CAKeyframeAnimation *)carAnimationWith:(NSString *)carImageName TrackLayer:(CAShapeLayer *)track AnimationDuration:(CFTimeInterval)duration BeginTime:(CFTimeInterval)beginTime{
    CALayer *car = [[CALayer alloc] init];
    car.frame = CGRectMake(0, 0, 22, 15);
    car.contents = (__bridge id _Nullable)([UIImage imageNamed:carImageName].CGImage);
    
    CAKeyframeAnimation *ani = [CAKeyframeAnimation animationWithKeyPath:@"position"];
    ani.path = track.path;
    
    ani.duration = duration;
    ani.beginTime = beginTime;
    ani.autoreverses = NO;
    ani.repeatCount = CGFLOAT_MAX;
    ani.calculationMode = kCAAnimationPaced;
    ani.rotationMode = kCAAnimationRotateAuto;
    
    [track addSublayer:car];
    [car addAnimation:ani forKey:@"carAni"];
    
    return ani;
}
-(void)initGreenTrack{
    _greenTrack = [[CAShapeLayer alloc] init];
    _greenTrack.lineWidth = 5;
    _greenTrack.strokeColor = [UIColor colorWithDisplayP3Red:0.0 / 255.0 green:147.0 / 255.0 blue:163.0 /255.0  alpha:1.0].CGColor;
    //    绿色铁轨的火车从右侧进入，所以从右侧开始绘画。需要画三条曲线，右边一条+中间的圆圈+左边一条
    UIBezierPath *path = [[UIBezierPath alloc] init];
    [path moveToPoint:CGPointMake(SCREENSIZE.width + 10, k_LAND_BEGIN_HEIGHT)];
    [path addLineToPoint:CGPointMake(SCREENSIZE.width + 10, SCREENSIZE.height - 70)];
    [path addQuadCurveToPoint:CGPointMake(SCREENSIZE.width / 1.5, SCREENSIZE.height - 70) controlPoint:CGPointMake(SCREENSIZE.width - 150, 200)];
    
    //    画圆圈
    [path addArcWithCenter:CGPointMake(SCREENSIZE.width / 1.6, SCREENSIZE.height - 140) radius:70 startAngle:M_PI_2 endAngle:2.5 * M_PI clockwise:YES];
    
    [path addCurveToPoint:CGPointMake(0, SCREENSIZE.height - 100) controlPoint1:CGPointMake(SCREENSIZE.width / 1.8 - 60, SCREENSIZE.height - 60) controlPoint2:CGPointMake(150, SCREENSIZE.height / 2.3)];
    
    [path addLineToPoint:CGPointMake(- 10, k_LAND_BEGIN_HEIGHT)];
    _greenTrack.path = path.CGPath;
    _greenTrack.fillColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"green"]].CGColor;
    [self.view.layer addSublayer:_greenTrack];
    
    // 加入镂空的虚线
    CAShapeLayer *trackLine = [[CAShapeLayer alloc] init];
    trackLine.lineCap = kCALineCapRound;
    trackLine.strokeColor = [UIColor whiteColor].CGColor;
    
    trackLine.lineDashPattern = @[@1.0,@6.0];
    trackLine.lineWidth = 2.5;
    trackLine.fillColor = [UIColor clearColor].CGColor;
    trackLine.path = path.CGPath;
    [_greenTrack addSublayer:trackLine];
}
@end
